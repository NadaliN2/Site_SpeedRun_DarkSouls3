 /* --------------------------------------------------------------------------
    VALIDAÇÃO DE FORMULÁRIO
    -------------------------------------------------------------------------- */
const formPesquisa = document.getElementById("aluno_form_pesquisa");
const msgErro = document.getElementById("aluno_msg_erro");
const msgSucesso = document.getElementById("aluno_msg_sucesso");

formPesquisa.addEventListener("submit", (evento) => {
    evento.preventDefault();

    // Leitura de valores
    const nomeValor = document.getElementById("aluno_input_nome").value.trim();
    const emailValor = document.getElementById("aluno_input_email").value.trim();
    const idadeRaw = document.getElementById("aluno_input_idade").value.trim();
    const idadeValor = Number(idadeRaw);
    
    // Radio button
    const radioGosta = document.querySelector('input[name="gosta_speedrun"]:checked');
    
    // Selects
    const selectCategoria = document.getElementById("aluno_select_categoria").value;
    const selectFrequencia = document.getElementById("aluno_select_frequencia").value;
    
    // Textarea
    const mensagemValor = document.getElementById("aluno_textarea_mensagem").value.trim();

    // Limpeza de avisos anteriores
    msgErro.classList.add("pietro_oculto");
    msgSucesso.classList.add("pietro_oculto");
    msgErro.textContent = "";
    msgSucesso.textContent = "";

    if (nomeValor === "" || nomeValor.length < 3) {
        exibirErro("Campo 1: Por favor, preencha seu nome completo com pelo menos 3 caracteres.");
    } else if (emailValor === "" || !emailValor.includes("@gmail.com")) {
        exibirErro("Campo 2: Informe um gmail válido");
    } else if (idadeRaw === "" || isNaN(idadeValor) || idadeValor < 10 || idadeValor > 120) {
        exibirErro("Campo 3: Digite uma idade válida em número entre 10 e 120 anos.");
    } else if (!radioGosta) {
        exibirErro("Campo 4: Selecione uma opção para a pergunta se você gosta de speedruns.");
    } else if (selectCategoria === "") {
        exibirErro("Campo 5: Selecione o que mais chamou sua atenção entre as categorias.");
    } else if (selectFrequencia === "") {
        exibirErro("Campo 6: Escolha a frequência com que assiste aos recordes mundiais.");
    } else {
        msgSucesso.textContent = "Excelente! Sua pesquisa sobre Speedruns de Dark Souls 3 foi validada e enviada com sucesso!";
        msgSucesso.classList.remove("pietro_oculto");
        
        // reset() no formulário
            
    }
});

function exibirErro(mensagem) {
    msgErro.textContent = mensagem;
    msgErro.classList.remove("pietro_oculto");
}


/* --------------------------------------------------------------------------
    MODO CLARO / ESCURO
    -------------------------------------------------------------------------- */
const btnTema = document.getElementById("pietro_btn_tema");
btnTema.addEventListener("click", () => {
    document.body.classList.toggle("bruno_modo_claro");
});


/* --------------------------------------------------------------------------
    SISTEMA DE ABAS
    -------------------------------------------------------------------------- */
const botoesAbas = document.querySelectorAll(".pietro_tab_btn");
const paineisAbas = document.querySelectorAll(".bruno_painel_aba");

botoesAbas.forEach((botao) => {
    botao.addEventListener("click", () => {
        // Remove a classe ativa de todos os botões e painéis
        botoesAbas.forEach(b => b.classList.remove("pietro_tab_ativo"));
        paineisAbas.forEach(p => p.classList.remove("bruno_painel_ativo"));

        // Ativa o botão clicado
        botao.classList.add("pietro_tab_ativo");

        // Exibe o painel com o ID correspondente ao atributo data-alvo
        const idAlvo = botao.getAttribute("data-alvo");
        const painelAlvo = document.getElementById(idAlvo);
        if (painelAlvo) {
            painelAlvo.classList.add("bruno_painel_ativo");
        }
    });
});


/* --------------------------------------------------------------------------
    CARROSSEL DE IMAGENS DO ANY% 
    -------------------------------------------------------------------------- */
const slides = document.querySelectorAll(".bruno_card");
const btnPrev = document.getElementById("aluno_btn_prev");
const btnNext = document.getElementById("aluno_btn_next");
const indicador = document.getElementById("bruno_indicador_carrossel");
let indiceAtual = 0;

function atualizarCarrossel() {
    slides.forEach((slide, index) => {
        slide.classList.remove("bruno_card_visivel");
        if (index === indiceAtual) {
            slide.classList.add("bruno_card_visivel");
        }
    });
    if (indicador) {
        indicador.textContent = `Imagem ${indiceAtual + 1} de ${slides.length}`;
    }
}

if (btnPrev && btnNext && slides.length > 0) {
    btnNext.addEventListener("click", () => {
        indiceAtual = (indiceAtual + 1) % slides.length;
        atualizarCarrossel();
    });

    btnPrev.addEventListener("click", () => {
        indiceAtual = (indiceAtual - 1 + slides.length) % slides.length;
        atualizarCarrossel();
    });
}